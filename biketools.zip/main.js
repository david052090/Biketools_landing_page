document.querySelector(".menu-btn").addEventListener("click", () => {
  document.querySelector(".menu-links").classList.toggle("show");
});
